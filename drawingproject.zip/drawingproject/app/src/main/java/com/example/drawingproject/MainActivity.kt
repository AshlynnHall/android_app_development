/*
# Overview

This is a drawing app that allows the user to draw on the screen with their finger
if a touch screen is available and with a mouse if not.

I have always loved art and found that there is some art in software development. This
was an opportunity to kind of merge the two and create a drawing app.

# Video Demonstration

[Software Demo Video](https://youtu.be/-IBPYLCq9TI)

# Development Environment

I used Android Studio and the emulator inside as my test device.

I used Kotlin.

# Useful Websites

{Make a list of websites that you found helpful in this project}
* [CodeAcademy][https://www.codecademy.com/learn/introduction-to-android-development]
* [Youtube](http://www.Youtube.com)

# Future Work

{Make a list of things that you need to fix, improve, and add in the future.}
* I would LOVE to add different colors to this software.
* I want to make it so you can erase lines.
* I want to add a download feature that let's you save your pieces.

 */

package com.example.drawingproject

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.drawingproject.ui.theme.DrawingprojectTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DrawingprojectTheme {
                DrawingCanvas ()
            }
        }
    }
}



@Composable
fun DrawingCanvas() {
    val lines = remember {
        mutableListOf<Line>()
    }

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(key1 = true) {
                detectDragGestures { change, dragAmount ->
                    change.consume()

                    val line = Line(
                        start = change.position - dragAmount,
                        end = change.position
                    )

                    lines.add(line)
                }
            }
    ){
        lines.forEach { line ->
            drawLine(
                color = line.color,
                start = line.start,
                end = line.end,
                strokeWidth = line.strokeWidth.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}

data class Line (
    val start: Offset,
    val end: Offset,
    val color: Color = Color.Black,
    val strokeWidth: Dp = 1.dp
)